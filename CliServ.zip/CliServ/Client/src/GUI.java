import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Group;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.ListSelectionListener;

public class GUI extends JPanel {
	
	static ArrayList<Employee> em = new ArrayList<Employee>();
	
	private String fnameVal, lnameVal, depVal, numVal;
	private boolean maleVal = false;
	private boolean femaleVal = false;
	private boolean otherVal = false;
	
	private JLabel fname;
    private JLabel lname;
    private JLabel dep;
    private JLabel num;
    private JLabel gender;
    
    private JButton fireButton;
    private JTextField titleName;
    
    private String fnamestring = "First name: ";
    private String lnamestring = "Last name: ";
    private String depstring = "Department: ";
    private String numstring = "Phone number: ";
    private String malestring = "Male";
    private String femalestring = "Female";
    private String otherstring = "Other";
    private String genderstring = "Gender: ";
    private String submitString = "Submit";
    private String exitString = "Exit";
    
    private JFormattedTextField fnameField;
    private JFormattedTextField lnameField;
    private JFormattedTextField depField;
    private JFormattedTextField numField;
    private JRadioButton maleButton = new JRadioButton(malestring);
    private JRadioButton femaleButton = new JRadioButton(femalestring);
    private JRadioButton otherButton = new JRadioButton(otherstring);
    private JButton submitButton = new JButton (submitString);
    private JButton exitButton = new JButton (exitString);
    
    public GUI() {
        super(new BorderLayout());
        
        //Create submit button
        submitButton.setHorizontalTextPosition(AbstractButton.LEADING);
        submitButton.addPropertyChangeListener("submit", new ButtonListener());
        exitButton.addPropertyChangeListener("exit", new ButtonListener());
 
        //Create the labels.
        fname = new JLabel(fnamestring);
        lname = new JLabel(lnamestring);
        dep = new JLabel(depstring);
        num = new JLabel(numstring);
        gender = new JLabel(genderstring);
 
        //Create the text fields and set them up.
        fnameField = new JFormattedTextField();
        fnameField.setValue(fname);
        fnameField.setColumns(10);
 
        lnameField = new JFormattedTextField();
        lnameField.setValue(lname);
        lnameField.setColumns(10);
 
        depField = new JFormattedTextField();
        depField.setValue(dep);
        depField.setColumns(10);
 
        numField = new JFormattedTextField();
        numField.setValue(numField);
        numField.setColumns(10);
 
        //Tell accessibility tools about label/textfield pairs.
        fname.setLabelFor(fnameField);
        lname.setLabelFor(lnameField);
        dep.setLabelFor(depField);
        num.setLabelFor(numField);
        
        
      //Create the radio buttons.
        maleButton.setMnemonic(KeyEvent.VK_B);
        maleButton.setActionCommand(malestring);
        maleButton.setSelected(true);
 
        femaleButton.setMnemonic(KeyEvent.VK_C);
        femaleButton.setActionCommand(femalestring);
 
        otherButton.setMnemonic(KeyEvent.VK_D);
        otherButton.setActionCommand(otherstring);
        
      //Group the radio buttons.
        ButtonGroup group = new ButtonGroup();
        group.add(maleButton);
        group.add(femaleButton);
        group.add(otherButton);
 
        //Lay out the labels in a panel.
        JPanel labelPane = new JPanel(new GridLayout(0,1));
        labelPane.add(fname);
        labelPane.add(lname);
        labelPane.add(dep);
        labelPane.add(num);
//        
//        //layout buttons in a panel
        JPanel buttonPane = new JPanel(new GridLayout(0,1));
        buttonPane.add(gender);
        buttonPane.add(maleButton);
        buttonPane.add(femaleButton);
        buttonPane.add(otherButton);
 
        //Layout the text fields in a panel.
        JPanel fieldPane = new JPanel(new GridLayout(0,1));
        fieldPane.add(fnameField);
        fieldPane.add(lnameField);
        fieldPane.add(depField);
        fieldPane.add(numField);
        
        //Layout the submit and exit fields in a panel
//        JPanel endPane = new JPanel(new GridLayout(0,1));
        buttonPane.add(submitButton);
        buttonPane.add(exitButton);
 
        //Put the panels in this panel, labels on left,
        //text fields on right.
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(labelPane, BorderLayout.LINE_START);
        add(fieldPane, BorderLayout.CENTER);
        add(buttonPane, BorderLayout.SOUTH);
//        add(buttonPane, BorderLayout.SOUTH);
//        add(endPane, BorderLayout.PAGE_END);
    }
    
    private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("Item Selection");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 
        //Add contents to the window.
        frame.add(new GUI());
        
      //Create and set up the content pane.
        JComponent newContentPane = new GUI();
        newContentPane.setOpaque(true); //content panes must be opaque
        frame.setContentPane(newContentPane);
 
        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
    
    public static ArrayList<Employee> run() {
        //Schedule a job for the event dispatch thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //Turn off metal's use of bold fonts
            UIManager.put("swing.boldMetal", Boolean.FALSE);
                createAndShowGUI();
            }
        });
        
        return em;
    }
    
	class ButtonListener implements PropertyChangeListener {
		public void propertyChange(PropertyChangeEvent evt) {
			// TODO Auto-generated method stub
			Object source = evt.getSource();
			if (source == submitButton) {
				changeProperties();
			}
		}
	}
	
	public void changeProperties () {
		if (maleButton.isSelected()) maleVal = true;
		else if (femaleButton.isSelected()) femaleVal = true;
		else otherVal = true;
		numVal = numField.getText();
		fnameVal = fnameField.getText();
		lnameVal = lnameField.getText();
		depVal = depField.getText();
		
		em.add(new Employee(fnameVal, lnameVal, depVal, numVal));
	}

}
